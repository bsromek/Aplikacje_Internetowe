module.exports = (sequelize) => {
  const Sequelize = require('sequelize');
  return sequelize.define('Order', {
    id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
    userId: { type: Sequelize.INTEGER, allowNull: false },
    bookId: { type: Sequelize.INTEGER, allowNull: false },
    quantity: { type: Sequelize.INTEGER, allowNull: false }
  });
};