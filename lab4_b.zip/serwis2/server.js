const express = require('express');
const Sequelize = require('sequelize');
const axios = require('axios');
const jwt = require('jsonwebtoken');

const app = express();
app.use(express.json());

const SECRET = 'tajny_klucz_jwt';

const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: './database.sqlite',
  logging: false
});

const Order = require('./models/order')(sequelize);

sequelize.sync().then(() => {
  console.log('Orders service - port 3002');
});

function authenticate(req, res, next) {
  const auth = req.headers['authorization'];
  if (!auth) return res.status(401).json({ error: 'No token' });
  const token = auth.split(' ')[1];
  try {
    req.user = jwt.verify(token, SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
}

app.get('/api/orders/:userId', async (req, res) => {
  res.json(await Order.findAll({ where: { userId: req.params.userId } }));
});

app.post('/api/orders', authenticate, async (req, res) => {
  const { userId, bookId, quantity } = req.body;
  try {
    await axios.get(`http://localhost:3001/api/books/${bookId}`);
  } catch {
    return res.status(400).json({ error: 'Book does not exist' });
  }
  const order = await Order.create({ userId, bookId, quantity });
  res.json({ id: order.id });
});

app.delete('/api/orders/:orderId', authenticate, async (req, res) => {
  await Order.destroy({ where: { id: req.params.orderId } });
  res.json({ status: 'deleted' });
});

app.patch('/api/orders/:orderId', authenticate, async (req, res) => {
  await Order.update(req.body, { where: { id: req.params.orderId } });
  res.json({ status: 'updated' });
});

app.listen(3002);