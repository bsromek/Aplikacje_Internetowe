import React, { useState } from "react";
import Dodawanie from "./Dodawanie";

interface Student {
  imie: string;
  nazwisko: string;
  rocznik: number;
}

function StudentManager() {
  const [studenci, setStudenci] = useState<Student[]>([
    { imie: "Jan", nazwisko: "Kowalski", rocznik: 2000 },
    { imie: "Anna", nazwisko: "Nowak", rocznik: 1999 },
    { imie: "Piotr", nazwisko: "Wiśniewski", rocznik: 2001 },
  ]);

  const dodajStudenta = (student: Student) => {
    setStudenci((prev) => [...prev, student]);
  };

  return (
    <div>
      <h2>Lista studentów</h2>
      <table border={1}>
        <thead>
          <tr>
            <th>Imię</th>
            <th>Nazwisko</th>
            <th>Rocznik</th>
          </tr>
        </thead>
        <tbody>
          {studenci.map((student, index) => (
            <tr key={index}>
              <td>{student.imie}</td>
              <td>{student.nazwisko}</td>
              <td>{student.rocznik}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <Dodawanie dodajStudenta={dodajStudenta} />
    </div>
  );
}

export default StudentManager;
