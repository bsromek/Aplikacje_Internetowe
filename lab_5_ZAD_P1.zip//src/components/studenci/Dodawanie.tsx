import React, { useState } from "react";

interface Student {
  imie: string;
  nazwisko: string;
  rocznik: number;
}

type DodawanieProps = {
  dodajStudenta: (student: Student) => void;
};

function Dodawanie(props: DodawanieProps) {
  const [imie, setImie] = useState("");
  const [nazwisko, setNazwisko] = useState("");
  const [rocznik, setRocznik] = useState("");

  const handleDodaj = () => {
    if (!imie || !nazwisko || !rocznik) {
      alert("Wszystkie pola muszą być wypełnione");
      return;
    }
    const rocznikNumber = Number(rocznik);
    if (isNaN(rocznikNumber)) {
      alert("Rocznik musi być liczbą");
      return;
    }
    props.dodajStudenta({ imie, nazwisko, rocznik: rocznikNumber });
    setImie("");
    setNazwisko("");
    setRocznik("");
  };

  return (
    <div>
      <h3>Dodawanie nowego studenta</h3>
      <input
        type="text"
        placeholder="Imię"
        value={imie}
        onChange={(e) => setImie(e.target.value)}
      />
      <input
        type="text"
        placeholder="Nazwisko"
        value={nazwisko}
        onChange={(e) => setNazwisko(e.target.value)}
      />
      <input
        type="text"
        placeholder="Rocznik"
        value={rocznik}
        onChange={(e) => setRocznik(e.target.value)}
      />
      <button onClick={handleDodaj}>Dodaj</button>
    </div>
  );
}

export default Dodawanie;
