import React from "react";

interface Student {
  imie: string;
  nazwisko: string;
  rocznik: number;
}

function Studenci() {
  const Students: Student[] = [
    { imie: "Jan", nazwisko: "Kowalski", rocznik: 2000 },
    { imie: "Anna", nazwisko: "Nowak", rocznik: 1999 },
    { imie: "Piotr", nazwisko: "Wiśniewski", rocznik: 2001 },
  ];

  return (
    <div>
      <h2>Lista studentów</h2>
      <table border={1}>
        <thead>
          <tr>
            <th>Imię</th>
            <th>Nazwisko</th>
            <th>Rocznik</th>
          </tr>
        </thead>
        <tbody>
          {Students.map((student, index) => (
            <tr key={index}>
              <td>{student.imie}</td>
              <td>{student.nazwisko}</td>
              <td>{student.rocznik}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Studenci;
