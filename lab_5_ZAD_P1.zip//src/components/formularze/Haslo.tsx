import React, { useState } from "react";

function Haslo() {
  const [haslo1, setHaslo1] = useState("");
  const [haslo2, setHaslo2] = useState("");

  const handleHaslo1 = (event: React.ChangeEvent<HTMLInputElement>) => {
    setHaslo1(event.target.value);
  };

  const handleHaslo2 = (event: React.ChangeEvent<HTMLInputElement>) => {
    setHaslo2(event.target.value);
  };

  let wiadomosc = "";
  if (haslo1 === "" && haslo2 === "") {
    wiadomosc = "Proszę wprowadzić hasło";
  } else if (haslo1 !== haslo2) {
    wiadomosc = "Hasła nie są zgodne";
  }

  return (
    <div>
      <div>
        <label>Hasło: </label>
        <input type="text" value={haslo1} onChange={handleHaslo1} />
      </div>
      <div>
        <label>Powtórz Hasło: </label>
        <input type="text" value={haslo2} onChange={handleHaslo2} />
      </div>
      <div>{wiadomosc}</div>
    </div>
  );
}

export default Haslo;
