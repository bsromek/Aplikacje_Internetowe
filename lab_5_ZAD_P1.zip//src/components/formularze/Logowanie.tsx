import React, { useState } from "react";

function Logowanie() {
  const [nazwa, setNazwa] = useState("");
  const [haslo1, setHaslo1] = useState("");
  const [haslo2, setHaslo2] = useState("");

  const handleNazwa = (event: React.ChangeEvent<HTMLInputElement>) => {
    setNazwa(event.target.value);
  };

  const handleHaslo1 = (event: React.ChangeEvent<HTMLInputElement>) => {
    setHaslo1(event.target.value);
  };

  const handleHaslo2 = (event: React.ChangeEvent<HTMLInputElement>) => {
    setHaslo2(event.target.value);
  };

  const wszystkiePolaWypelnione =
    nazwa !== "" && haslo1 !== "" && haslo2 !== "";

  const handleLogowanie = () => {
    if (haslo1 !== haslo2) {
      alert("Hasła nie są zgodne");
    } else {
      alert("Zalogowano poprawnie");
    }
  };

  return (
    <div>
      <div>
        <label>Nazwa użytkownika: </label>
        <input type="text" value={nazwa} onChange={handleNazwa} />
      </div>
      <div>
        <label>Hasło: </label>
        <input type="text" value={haslo1} onChange={handleHaslo1} />
      </div>
      <div>
        <label>Powtórz Hasło: </label>
        <input type="text" value={haslo2} onChange={handleHaslo2} />
      </div>
      <button onClick={handleLogowanie} disabled={!wszystkiePolaWypelnione}>
        Logowanie
      </button>
    </div>
  );
}

export default Logowanie;
