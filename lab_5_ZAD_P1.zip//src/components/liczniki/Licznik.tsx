import React, { useState } from "react";

function Licznik() {
  const [count, setCount] = useState(0);

  const dodaj = () => {
    setCount(count + 1);
  };

  return (
    <div>
      <div>Licznik: {count}</div>
      <button onClick={dodaj}>Dodaj</button>
    </div>
  );
}

export default Licznik;
