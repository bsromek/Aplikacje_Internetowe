import React, { useState } from "react";
import Przycisk from "./Przycisk";

function NowyLicznik() {
  const [count, setCount] = useState(0);

  const dodaj = () => {
    setCount(count + 1);
  };

  return (
    <div>
      <div>Licznik: {count}</div>
      <Przycisk dodaj={dodaj} />
    </div>
  );
}

export default NowyLicznik;
