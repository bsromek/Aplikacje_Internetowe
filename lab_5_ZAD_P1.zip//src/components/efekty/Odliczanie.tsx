import React, { useEffect, useState } from "react";

function Odliczanie() {
  const [czas, setCzas] = useState(15.0);
  const [dziala, setDziala] = useState(false);

  useEffect(() => {
    if (!dziala) {
      return;
    }

    const interval = setInterval(() => {
      setCzas((prev) => {
        if (prev <= 0.1) {
          return 0;
        }
        return Math.round((prev - 0.1) * 10) / 10;
      });
    }, 100);

    return () => clearInterval(interval);
  }, [dziala]);

  const handleClick = () => {
    setDziala(!dziala);
  };

  let tekstPrzycisku = dziala ? "STOP" : "START";
  let disabled = false;

  if (czas === 0) {
    tekstPrzycisku = "Odliczanie zakończone";
    disabled = true;
  }

  return (
    <div>
      <div>{czas.toFixed(1)} sek</div>
      <button onClick={handleClick} disabled={disabled}>
        {tekstPrzycisku}
      </button>
    </div>
  );
}

export default Odliczanie;
