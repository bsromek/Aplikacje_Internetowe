import React, { useEffect, useState } from "react";

function LicznikEfekt() {
  const [count, setCount] = useState(0);

  const dodaj = () => {
    setCount(count + 1);
  };

  useEffect(() => {
    console.log("Hello world");
  }, []);

  useEffect(() => {
    if (count > 0) {
      console.log("Licznik zwiększył się do " + count);
    }
  }, [count]);

  return (
    <div>
      <div>Licznik: {count}</div>
      <button onClick={dodaj}>Dodaj</button>
    </div>
  );
}

export default LicznikEfekt;
