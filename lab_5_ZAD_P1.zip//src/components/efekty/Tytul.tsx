import React, { useEffect, useState } from "react";

function Tytul() {
  const [tytul, setTytul] = useState("");

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setTytul(event.target.value);
  };

  useEffect(() => {
    document.title = tytul;
    //console.log(tytul);
  }, [tytul]);

  return (
    <div>
      <h2>Tytuł strony</h2>
      <input type="text" value={tytul} onChange={handleChange} />
    </div>
  );
}

export default Tytul;
