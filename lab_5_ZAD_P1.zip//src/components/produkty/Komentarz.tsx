import { useState } from "react";

interface User {
  id: number;
  username: string;
  fullName: string;
}

interface KomentarzProps {
  id: number;
  body: string;
  postId: number;
  likes: number;
  user: User;
}

function Komentarz(props: KomentarzProps) {
  const [likes, setLikes] = useState<number>(props.likes);

  return (
    <div
      style={{
        border: "1px solid black",
        padding: "10px",
        marginBottom: "10px",
      }}
    >
      <div>
        <b>{props.user.fullName}</b> (@{props.user.username})
      </div>
      <div>{props.body}</div>
      <div>Post ID: {props.postId}</div>

      <div>
        <button onClick={() => setLikes(likes - 1)}>👎</button>
        <span style={{ margin: "0 10px" }}>{likes}</span>
        <button onClick={() => setLikes(likes + 1)}>👍</button>
      </div>
    </div>
  );
}

export default Komentarz;
