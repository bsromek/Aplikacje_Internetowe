import React from "react";
import Produkt from "./Produkt";

function NowyKoszyk() {
  const produkty: string[] = [
    "Jabłko",
    "Gruszka",
    "Banan",
    "Pomarańcza",
    "Truskawka",
  ];

  return (
    <div>
      <h2>Nowy koszyk</h2>
      {produkty.map((nazwa, index) => (
        <Produkt key={index} nazwa={nazwa} />
      ))}
    </div>
  );
}

export default NowyKoszyk;
