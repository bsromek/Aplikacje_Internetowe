import { useEffect, useState } from "react";

function LicznikP2() {
  const [licznik, setLicznik] = useState<number>(() => {
    const zapisany = localStorage.getItem("licznikP2");
    return zapisany ? Number(zapisany) : 0;
  });

  useEffect(() => {
    localStorage.setItem("licznikP2", licznik.toString());
  }, [licznik]);

  return (
    <div>
      <div>Licznik: {licznik}</div>
      <button onClick={() => setLicznik(licznik + 1)}>Dodaj</button>
    </div>
  );
}

export default LicznikP2;
