import React from "react";
import NowyKoszyk from "./components/koszyk/NowyKoszyk";
import NowyLicznik from "./components/liczniki/NowyLicznik";
import Formularz from "./components/formularze/Formularz";
import Logowanie from "./components/formularze/Logowanie";
import Ternary from "./components/inne/Ternary";
import Aktualizacja from "./components/inne/Aktualizacja";
import StudentManager from "./components/studenci/StudentManager";
import LicznikEfekt from "./components/efekty/LicznikEfekt";
import Tytul from "./components/efekty/Tytul";
import Odliczanie from "./components/efekty/Odliczanie";
import Komentarz from "./components/produkty/Komentarz";
import Komentarze from "./components/produkty/Komentarze";

function App() {
  return (
    <div>
      <NowyKoszyk />
      <br />
      <NowyLicznik />
      <br />
      <Formularz />
      <br />
      <Logowanie />
      <br />
      <Ternary />
      <br />
      <Aktualizacja />
      <br />
      <StudentManager />
      <br />
      <LicznikEfekt />
      <br />
      <Tytul />
      <br />
      <Odliczanie />
      <br />
      <Komentarz
        id={1}
        body="lubie placki"
        postId={1}
        likes={5}
        user={{
          id: 1,
          username: "JanekPL",
          fullName: "Jan Kowalski",
        }}
      />
      <br />
      <Komentarze />
    </div>
  );
}

export default App;
