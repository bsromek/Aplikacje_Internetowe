const express = require('express');
const Sequelize = require('sequelize');
const jwt = require('jsonwebtoken');

const app = express();
app.use(express.json());

const SECRET = 'tajny_klucz_jwt';

const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: './database.sqlite',
  logging: false
});

const Book = require('./models/book')(sequelize, Sequelize.DataTypes);

sequelize.sync().then(() => {
  console.log('Books service - port 3001');
});

function authenticate(req, res, next) {
  const auth = req.headers['authorization'];
  if (!auth) return res.status(401).json({ error: 'No token' });
  const token = auth.split(' ')[1];
  try {
    req.user = jwt.verify(token, SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
}

app.get('/api/books', async (req, res) => {
  res.json(await Book.findAll());
});

app.get('/api/books/:bookId', async (req, res) => {
  const book = await Book.findByPk(req.params.bookId);
  if (!book) return res.status(404).json({ error: 'Book not found' });
  res.json(book);
});

app.post('/api/books', authenticate, async (req, res) => {
  const { title, author, year } = req.body;
  if (!title || !author || !year) return res.status(400).json({ error: 'Missing fields' });
  const book = await Book.create({ title, author, year });
  res.json({ id: book.id });
});

app.delete('/api/books/:bookId', authenticate, async (req, res) => {
  const deleted = await Book.destroy({ where: { id: req.params.bookId } });
  if (!deleted) return res.status(404).json({ error: 'Book not found' });
  res.json({ message: 'Book deleted' });
});

app.listen(3001);