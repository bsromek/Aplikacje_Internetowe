import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./components/liczniki/Home";
import Blog from "./components/liczniki/Blog";
import Article from "./components/liczniki/Article";
import Dodaj from "./components/liczniki/Dodaj";
import LicznikP2 from "./components/liczniki/LicznikP2";

function App() {
  return (
    <BrowserRouter>
      <LicznikP2 />
      <br />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/blog" element={<Blog />} />
        <Route path="/article/:id" element={<Article />} />
        <Route path="/dodaj" element={<Dodaj />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
