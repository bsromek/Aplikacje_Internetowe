import { useParams } from "react-router-dom";

interface Article {
  id: number;
  title: string;
  body: string;
}

function Article() {
  const { id } = useParams();
  const articles: Article[] = JSON.parse(
    localStorage.getItem("articles") || "[]"
  );

  const article = articles.find((a) => a.id === Number(id));

  if (!article) {
    return <div>Nie znaleziono artykułu</div>;
  }

  return (
    <div>
      <h2>{article.title}</h2>
      <p>{article.body}</p>
    </div>
  );
}

export default Article;
