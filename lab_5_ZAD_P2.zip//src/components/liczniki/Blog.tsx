import { Link } from "react-router-dom";

interface Article {
  id: number;
  title: string;
  body: string;
}

function Blog() {
  const articles: Article[] = JSON.parse(
    localStorage.getItem("articles") || "[]"
  );

  return (
    <div>
      <h2>Blog</h2>

      <ul>
        {articles.map((a) => (
          <li key={a.id}>
            <Link to={`/article/${a.id}`}>{a.title}</Link>
          </li>
        ))}
      </ul>

      <Link to="/dodaj">Dodaj artykuł</Link>
    </div>
  );
}

export default Blog;
