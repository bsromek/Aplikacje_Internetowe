import { useState } from "react";
import { useNavigate } from "react-router-dom";

interface Article {
  id: number;
  title: string;
  body: string;
}

function Dodaj() {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const navigate = useNavigate();

  const dodaj = () => {
    if (!title || !body) return;

    const articles: Article[] = JSON.parse(
      localStorage.getItem("articles") || "[]"
    );

    const nowy: Article = {
      id: Date.now(),
      title,
      body,
    };

    localStorage.setItem("articles", JSON.stringify([...articles, nowy]));
    navigate("/blog");
  };

  return (
    <div>
      <h2>Dodaj artykuł</h2>

      <input
        placeholder="Tytuł"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />
      <br />

      <textarea
        placeholder="Treść"
        value={body}
        onChange={(e) => setBody(e.target.value)}
      />
      <br />

      <button onClick={dodaj}>DODAJ</button>
    </div>
  );
}

export default Dodaj;
